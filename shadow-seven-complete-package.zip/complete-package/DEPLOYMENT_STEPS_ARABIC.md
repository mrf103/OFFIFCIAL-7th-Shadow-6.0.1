# خطوات نشر المكونات الثلاثة على الخادم

## معلومات الخادم
- **العنوان**: 46.224.225.96
- **المستخدم**: root
- **كلمة المرور**: mrfiras1Q@@@
- **نظام التشغيل**: Ubuntu 24.04

---

## ✅ الخطوات الأساسية

### الخطوة 1️⃣: الاتصال بالخادم عبر SSH

```bash
ssh root@46.224.225.96
```

عند المطالبة، أدخل كلمة المرور:
```
mrfiras1Q@@@
```

---

### الخطوة 2️⃣: التحقق من الملفات المنقولة

بعد الاتصال، تحقق من أن الملفات موجودة:

```bash
ls -la ~/ | grep -E 'deploy|website'
```

يجب أن ترى:
- ✅ `deploy.sh` (ملف النشر الرئيسي)
- ✅ `mrf103-website` (مجلد الموقع)

---

### الخطوة 3️⃣: تشغيل سكريبت النشر الرئيسي

```bash
sudo bash ~/deploy.sh
```

**ماذا يفعل هذا السكريبت؟**
- ✅ تثبيت Node.js و npm
- ✅ تثبيت Nginx (وكيل عكسي)
- ✅ تثبيت PM2 (إدارة العمليات)
- ✅ نشر تطبيق MRF103
- ✅ نشر منصة Shadow Seven
- ✅ إعداد قاعدة البيانات
- ✅ تكوين SSL/TLS

**المدة المتوقعة**: 10-15 دقيقة

---

### الخطوة 4️⃣: إدخال بيانات Supabase

عند المطالبة، أدخل:

```
عنوان Supabase: https://xxxxx.supabase.co
مفتاح Supabase Anon: eyJhbGc...
```

**أين تجد هذه البيانات؟**
1. اذهب إلى https://supabase.com
2. ادخل إلى مشروعك
3. اذهب إلى Settings → API
4. انسخ:
   - `Project URL`
   - `Anon public key`

---

### الخطوة 5️⃣: نشر الموقع التسويقي

```bash
cd ~/mrf103-website
sudo bash deploy-website.sh
```

**ماذا يفعل هذا السكريبت؟**
- ✅ تثبيت متطلبات الموقع
- ✅ بناء الموقع
- ✅ تشغيل الموقع على المنفذ 8000
- ✅ تكوين Nginx للموقع

**المدة المتوقعة**: 3-5 دقائق

---

## 🔍 التحقق من النشر

### 1. التحقق من حالة الخدمات

```bash
pm2 list
```

يجب أن ترى:
```
┌─────────────────┬─────┬─────────┬───────┐
│ App name        │ id  │ version │ mode  │
├─────────────────┼─────┼─────────┼───────┤
│ mrf103          │ 0   │ 1.0.0   │ fork  │
│ shadow-seven    │ 1   │ 1.0.0   │ fork  │
│ website         │ 2   │ 1.0.0   │ fork  │
└─────────────────┴─────┴─────────┴───────┘
```

### 2. عرض السجلات

```bash
# عرض سجلات جميع التطبيقات
pm2 logs

# عرض سجلات تطبيق معين
pm2 logs mrf103
pm2 logs shadow-seven
pm2 logs website
```

### 3. اختبار نقاط النهاية

```bash
# اختبار MRF103 API
curl http://localhost:3001

# اختبار Shadow Seven
curl http://localhost:3002

# اختبار الموقع
curl http://localhost:8000
```

### 4. الوصول عبر المتصفح

| التطبيق | الرابط |
|---|---|
| **الموقع الرئيسي** | http://46.224.225.96:8000 |
| **MRF103 API** | http://46.224.225.96/api |
| **Shadow Seven** | http://46.224.225.96 |

---

## ⚠️ استكشاف الأخطاء

### المشكلة: التطبيقات لا تبدأ

```bash
# عرض السجلات التفصيلية
pm2 logs

# إعادة تشغيل التطبيقات
pm2 restart all

# التحقق من موارد النظام
free -h
df -h /
```

### المشكلة: المنفذ قيد الاستخدام

```bash
# البحث عن العملية التي تستخدم المنفذ
sudo lsof -i :3001
sudo lsof -i :3002
sudo lsof -i :8000

# إيقاف العملية (استبدل PID برقم العملية)
sudo kill -9 PID
```

### المشكلة: أخطاء Nginx

```bash
# اختبار إعدادات Nginx
sudo nginx -t

# عرض السجلات
sudo tail -f /var/log/nginx/error.log

# إعادة تشغيل Nginx
sudo systemctl restart nginx
```

### المشكلة: فشل الاتصال بـ Supabase

```bash
# التحقق من بيانات الاعتماد
cat /opt/applications/mrf103/.env.production

# اختبار الاتصال
curl -I https://xxxxx.supabase.co

# إعادة تشغيل التطبيقات
pm2 restart all
```

---

## 📊 مراقبة التطبيقات

### مراقبة في الوقت الفعلي

```bash
pm2 monit
```

### عرض معلومات التطبيق

```bash
pm2 info mrf103
pm2 info shadow-seven
pm2 info website
```

### إعادة تشغيل التطبيقات

```bash
# إعادة تشغيل جميع التطبيقات
pm2 restart all

# إعادة تشغيل تطبيق معين
pm2 restart mrf103
pm2 restart shadow-seven

# إيقاف التطبيقات
pm2 stop all

# بدء التطبيقات
pm2 start all
```

---

## 🔐 إدارة البيانات الحساسة

### موقع ملفات البيئة

```bash
# MRF103
/opt/applications/mrf103/.env.production

# Shadow Seven
/opt/applications/shadow-seven/.env.production

# الموقع
/opt/websites/mrf103/.env
```

### تحديث بيانات Supabase

```bash
# تحرير ملف البيئة
sudo nano /opt/applications/mrf103/.env.production

# إعادة تشغيل التطبيق
pm2 restart mrf103
```

---

## 🚀 الخطوات الإضافية (اختيارية)

### 1. إعداد اسم نطاق (Domain)

```bash
# تحرير إعدادات Nginx
sudo nano /etc/nginx/sites-available/dual-apps

# ابحث عن server_name وأضف نطاقك
server_name yourdomain.com www.yourdomain.com;

# اختبر الإعدادات
sudo nginx -t

# أعد تشغيل Nginx
sudo systemctl reload nginx
```

### 2. إعداد SSL/TLS

```bash
# استخدم Certbot
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

### 3. النسخ الاحتياطية الآلية

```bash
# أنشئ سكريبت نسخ احتياطي
sudo nano /usr/local/bin/backup-mrf103.sh

# أضف المحتوى:
#!/bin/bash
BACKUP_DIR="/backups"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR
tar -czf $BACKUP_DIR/mrf103_$DATE.tar.gz /opt/applications/
tar -czf $BACKUP_DIR/website_$DATE.tar.gz /opt/websites/

# اجعله قابلاً للتنفيذ
sudo chmod +x /usr/local/bin/backup-mrf103.sh

# أضفه إلى cron (كل يوم الساعة 2 صباحاً)
sudo crontab -e
# أضف: 0 2 * * * /usr/local/bin/backup-mrf103.sh
```

---

## 📋 قائمة التحقق النهائية

- [ ] تم الاتصال بالخادم عبر SSH
- [ ] تم التحقق من وجود الملفات
- [ ] تم تشغيل سكريبت النشر الرئيسي
- [ ] تم إدخال بيانات Supabase
- [ ] تم نشر الموقع التسويقي
- [ ] تم التحقق من حالة الخدمات (pm2 list)
- [ ] تم اختبار نقاط النهاية
- [ ] تم الوصول إلى التطبيقات عبر المتصفح
- [ ] تم فحص السجلات للأخطاء

---

## 📞 الدعم والمساعدة

### الأوامر المفيدة

```bash
# عرض معلومات النظام
uname -a
free -h
df -h

# عرض العمليات الجارية
ps aux | grep node

# عرض استخدام المنافذ
netstat -tulpn | grep LISTEN

# عرض سجلات النظام
journalctl -xe

# عرض سجلات Nginx
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### الملفات المهمة

```bash
# إعدادات Nginx
/etc/nginx/sites-available/dual-apps

# سجلات PM2
~/.pm2/logs/

# سجلات Nginx
/var/log/nginx/

# تطبيقات
/opt/applications/

# مواقع
/opt/websites/
```

---

## ✅ النتيجة النهائية

بعد اتباع هذه الخطوات، ستكون لديك:

✅ **تطبيق MRF103 الجوال** - يعمل على المنفذ 3001
✅ **منصة Shadow Seven** - تعمل على المنفذ 3002
✅ **الموقع التسويقي** - يعمل على المنفذ 8000
✅ **Nginx** - يوجه حركة المرور إلى التطبيقات الصحيحة
✅ **PM2** - يدير العمليات ويعيد تشغيلها تلقائياً
✅ **Supabase** - قاعدة البيانات المشتركة

**الآن يمكنك الوصول إلى:**
- http://46.224.225.96:8000 (الموقع)
- http://46.224.225.96/api (MRF103)
- http://46.224.225.96 (Shadow Seven)

---

**دليل النشر - الإصدار 1.0**
منصة MRF103 - التطبيق الجوال المدعوم بالذكاء الاصطناعي
