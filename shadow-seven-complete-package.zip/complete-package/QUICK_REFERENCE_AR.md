# دليل سريع - خطوات النشر

## 🎯 الخطوات الأساسية (5 خطوات فقط)

### 1️⃣ الاتصال بالخادم
```bash
ssh root@46.224.225.96
# كلمة المرور: mrfiras1Q@@@
```

### 2️⃣ التحقق من الملفات
```bash
ls -la ~/ | grep deploy
```

### 3️⃣ نشر التطبيقات
```bash
sudo bash ~/deploy.sh
```
⏱️ المدة: 10-15 دقيقة

### 4️⃣ نشر الموقع
```bash
cd ~/mrf103-website
sudo bash deploy-website.sh
```
⏱️ المدة: 3-5 دقائق

### 5️⃣ التحقق
```bash
pm2 list
```

---

## 🌐 الوصول إلى التطبيقات

| التطبيق | الرابط | المنفذ |
|---|---|---|
| 🌍 الموقع | http://46.224.225.96:8000 | 8000 |
| 📱 MRF103 API | http://46.224.225.96/api | 3001 |
| 📚 Shadow Seven | http://46.224.225.96 | 3002 |

---

## 🔧 الأوامر المهمة

```bash
# عرض حالة التطبيقات
pm2 list

# عرض السجلات
pm2 logs

# إعادة تشغيل التطبيقات
pm2 restart all

# إيقاف التطبيقات
pm2 stop all

# بدء التطبيقات
pm2 start all

# مراقبة الموارد
pm2 monit
```

---

## ⚠️ استكشاف الأخطاء السريع

| المشكلة | الحل |
|---|---|
| التطبيقات لا تعمل | `pm2 logs` ثم `pm2 restart all` |
| المنفذ قيد الاستخدام | `sudo lsof -i :3001` ثم `sudo kill -9 PID` |
| أخطاء Nginx | `sudo nginx -t` ثم `sudo systemctl restart nginx` |
| مشاكل في قاعدة البيانات | تحقق من بيانات Supabase في `.env.production` |

---

## 📊 مراقبة النظام

```bash
# موارد النظام
free -h      # الذاكرة
df -h /      # المساحة
top          # العمليات

# السجلات
pm2 logs mrf103
pm2 logs shadow-seven
pm2 logs website

# Nginx
sudo tail -f /var/log/nginx/error.log
```

---

## 🔐 البيانات الحساسة

### ملفات البيئة
```bash
/opt/applications/mrf103/.env.production
/opt/applications/shadow-seven/.env.production
/opt/websites/mrf103/.env
```

### تحديث البيانات
```bash
sudo nano /opt/applications/mrf103/.env.production
pm2 restart mrf103
```

---

## ✅ قائمة التحقق

- [ ] SSH متصل
- [ ] الملفات موجودة
- [ ] سكريبت النشر انتهى
- [ ] الموقع منشور
- [ ] pm2 list يظهر 3 تطبيقات
- [ ] يمكن الوصول للتطبيقات عبر المتصفح

---

**نصيحة**: احفظ هذا الملف للرجوع إليه لاحقاً! 📌
