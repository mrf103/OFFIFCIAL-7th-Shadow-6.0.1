// Scroll Area Component
export default function ScrollArea() {
  return null;
}
