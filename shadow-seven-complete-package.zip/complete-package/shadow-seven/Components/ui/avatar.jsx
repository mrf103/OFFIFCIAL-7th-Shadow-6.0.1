// Avatar Component
export default function Avatar() {
  return null;
}
