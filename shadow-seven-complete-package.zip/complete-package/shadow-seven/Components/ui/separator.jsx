// Separator Component
export default function Separator() {
  return null;
}
