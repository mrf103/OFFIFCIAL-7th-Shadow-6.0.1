// Alert Dialog Component
export default function AlertDialog() {
  return null;
}
