// Input OTP Component
export default function InputOtp() {
  return null;
}
