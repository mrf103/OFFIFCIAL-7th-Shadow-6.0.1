// Resizable Component
export default function Resizable() {
  return null;
}
