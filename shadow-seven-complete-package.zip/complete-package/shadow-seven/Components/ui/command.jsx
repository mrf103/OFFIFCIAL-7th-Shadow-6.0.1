// Command Component
export default function Command() {
  return null;
}
