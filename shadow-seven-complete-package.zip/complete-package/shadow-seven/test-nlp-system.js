/**
 * اختبار نظام NLP المحلي
 */

import { quickFileAnalysis } from './Components/upload/TextAnalyzerEnhanced.js';
import { smartDivideChapters } from './utils/nlp/chapterDivider.js';
import { getTextStats } from './utils/nlp/arabicTokenizer.js';

// نص اختبار عربي
const testText = `
الفصل الأول: البداية

في يوم من الأيام، كان هناك شاب اسمه أحمد يحلم بأن يصبح كاتباً مشهوراً. كان يقضي ساعات طويلة في المكتبة يقرأ كل ما تقع عليه يداه من كتب وروايات.

كانت أمنيته الوحيدة أن يكتب قصة تلمس قلوب القراء وتبقى في ذاكرتهم للأبد. كان يعلم أن الطريق طويل وصعب، ولكنه لم يتوقف عن المحاولة يوماً واحداً.

في أحد الأيام، بينما كان يتصفح كتاباً قديماً في المكتبة، وجد بين صفحاته ورقة صفراء مكتوب عليها بخط جميل: "الكاتب الحقيقي هو من يكتب بقلبه قبل قلمه".

الفصل الثاني: التحدي

قرر أحمد أن يبدأ في كتابة روايته الأولى. اختار موضوعاً قريباً من قلبه، قصة عن الصداقة والوفاء والأحلام التي لا تموت.

كتب وكتب حتى ملأ عشرات الصفحات. كان يشعر بالسعادة في كل مرة ينهي فيها فصلاً جديداً. ولكن التحدي الحقيقي بدأ عندما أراد أن ينشر روايته.

رفضت دور النشر روايته مرة بعد أخرى. قالوا إن أسلوبه بحاجة إلى تطوير، وإن القصة تحتاج إلى مزيد من العمق. لكن أحمد لم ييأس.

الفصل الثالث: النجاح

بعد سنوات من المحاولة والتطوير، نجح أحمد أخيراً في نشر روايته. وكانت النتيجة أفضل مما توقع. أحب القراء القصة وانتشرت بسرعة.

أصبح أحمد كاتباً معروفاً، وتحقق حلمه الذي طالما سعى إليه. لكنه لم ينسَ أبداً تلك الورقة الصفراء التي وجدها في المكتبة، والتي غيرت حياته إلى الأبد.

النهاية
`;

console.log('🧪 اختبار نظام NLP المحلي\n');
console.log('=' .repeat(50));

// اختبار 1: إحصائيات النص
console.log('\n📊 اختبار 1: إحصائيات النص');
const stats = getTextStats(testText);
console.log('عدد الكلمات:', stats.words);
console.log('عدد الجمل:', stats.sentences);
console.log('عدد الفقرات:', stats.paragraphs);
console.log('متوسط الكلمات/جملة:', stats.avgWordsPerSentence.toFixed(1));
console.log('ثراء المفردات:', (stats.vocabularyRichness * 100).toFixed(1) + '%');

// اختبار 2: تقسيم الفصول
console.log('\n📖 اختبار 2: تقسيم الفصول الذكي');
const chapters = smartDivideChapters(testText);
console.log('الطريقة:', chapters.method);
console.log('عدد الفصول:', chapters.chapters?.length || chapters.actualChapters);
console.log('الفصول:');
chapters.chapters.forEach(ch => {
  console.log(`  - ${ch.title} (${ch.words || 'N/A'} كلمة)`);
});

// اختبار 3: تحليل سريع
console.log('\n⚡ اختبار 3: تحليل سريع');
quickFileAnalysis(testText).then(analysis => {
  console.log('عدد الكلمات:', analysis.word_count);
  console.log('الصفحات المقدرة:', analysis.estimated_pages);
  console.log('اللغة:', analysis.language);
  console.log('فصول مكتشفة:', analysis.detected_chapters);
  console.log('نوع المحتوى:', analysis.content_type);
  console.log('نسبة التكرار:', analysis.repetition_rate + '%');
  
  console.log('\n✅ جميع الاختبارات تمت بنجاح!');
}).catch(err => {
  console.error('❌ خطأ:', err.message);
});
