// Toggle Component
export default function Toggle() {
  return null;
}
