// Carousel Component
export default function Carousel() {
  return null;
}
