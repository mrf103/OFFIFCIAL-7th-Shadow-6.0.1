// Hover Card Component
export default function HoverCard() {
  return null;
}
