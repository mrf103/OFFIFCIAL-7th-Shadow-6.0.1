// Skeleton Component
export default function Skeleton() {
  return null;
}
