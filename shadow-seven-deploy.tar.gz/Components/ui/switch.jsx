// Switch Component
export default function Switch() {
  return null;
}
