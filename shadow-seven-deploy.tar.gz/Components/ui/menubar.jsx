// Menubar Component
export default function Menubar() {
  return null;
}
